jquery.smoothwheel
==================

Cross browser smooth mouse wheel and trackpad scrolling

View demo http://fatlinesofcode.github.com/jquery.smoothwheel/demo/smoothwheel.html